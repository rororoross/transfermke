<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package my-simone
 */

get_header(); ?>

	<div id="primary" class="content-area">
				<div id="calendar">
				<div id="calendar-header">Live Music</div>
			<?php
    $options = array(
	'limit' => 5,
	'scope' => 'upcoming',
	'show_tours' => 'no',
	'group_artists' => 'no',
	'artist_order' => 'alphabetical',
	'artist' => '',
	'time' => '',
	'tour' => '',
	'venue' => '',
	'show_feeds' => 'no',
	'link_text' => ''
    );
    echo gigpress_sidebar($options);
?>

			</div>
		</div> <!-- End of Calendar -->

<div id="modal-container">
		 <!-- Modal HTML embedded directly into document -->
  <div id="ex1" style="display:none;">
    <p><span>Thursday, October 30th at 7:30pm -</span> Eric Schoor Trio</p>
    <p><span>Thursday, November 6th at 7:30pm -</span> Eric Schoor Trio</p>
    <p><span>Thursday, November 13th at 7:30pm -</span> The Cherry Trio</p>
    <p><span>Thursday, November 20th at 7:30pm -</span> Eric Schoor Trio</p>
    <p><span>Thursday, November 27th -</span> Closed for Thanksgiving</p>
    <p><span>Thursday, December 4th at 7:30pm -</span> Eric Schoor Trio</p>
    <p><span>Thursday, December 18th at 7:30pm -</span> Eric Schoor Trio</p>
    <p><span>Thursday, January 29th at 7:30pm -</span> New Galaxy Quartet</p>
    <p><span>Thursday, March 5th at 7:30pm -</span> George Braith Quartet</p>
     <a href="#" rel="modal:close" class="close-modal"></a>
  </div>

  <!-- Link to open the modal -->

</div>
		<div class="social">
			<a href="http://www.facebook.com/transferMKE" target="_blank">
			
			<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
			<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
			<svg version="1.1" class="social-icons" id="Icons" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 width="28px" height="28px" viewBox="29 29 42 42" enable-background="new 29 29 42 42" xml:space="preserve">
			<path class="social-fill" id="Facebook" fill="#FFFFFF" d="M44.376,37.166c0,1.063,0,5.805,0,5.805h-4.253v7.099h4.253v21.094h8.737V50.07h5.862
				c0,0,0.55-3.404,0.815-7.125c-0.763,0-6.645,0-6.645,0s0-4.129,0-4.854c0-0.726,0.953-1.701,1.895-1.701c0.939,0,2.923,0,4.76,0
				c0-0.967,0-4.306,0-7.39c-2.452,0-5.242,0-6.473,0C44.161,29,44.376,36.105,44.376,37.166z"/>
			</svg></a>
			
			<a href="http://www.twitter.com/transferMKE" target="_blank">
			
			<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
			<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
			<svg version="1.1" class="social-icons" id="Icons" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 width="28px" height="28px" viewBox="29 29 42 42" enable-background="new 29 29 42 42" xml:space="preserve">
			<path class="social-fill" id="Twitter__x28_alt_x29_" fill="#FFFFFF" d="M66.27,47.976c2.345-0.193,3.936-1.259,4.548-2.706
				c-0.846,0.52-3.473,1.086-4.922,0.547c-0.071-0.34-0.15-0.664-0.229-0.957c-1.104-4.057-4.888-7.325-8.852-6.931
				c0.32-0.13,0.646-0.251,0.971-0.358c0.436-0.156,2.996-0.573,2.592-1.477c-0.339-0.794-3.467,0.602-4.056,0.783
				c0.777-0.293,2.063-0.795,2.201-1.688c-1.191,0.164-2.36,0.726-3.264,1.545c0.326-0.351,0.573-0.778,0.626-1.239
				c-3.177,2.029-5.032,6.121-6.534,10.09c-1.179-1.143-2.224-2.043-3.161-2.543c-2.63-1.41-5.775-2.882-10.712-4.715
				c-0.152,1.634,0.808,3.807,3.572,5.25c-0.599-0.08-1.693,0.099-2.57,0.309c0.357,1.871,1.522,3.412,4.676,4.158
				c-1.441,0.096-2.187,0.424-2.861,1.13c0.656,1.301,2.258,2.833,5.14,2.519c-3.204,1.381-1.306,3.938,1.301,3.557
				c-4.447,4.593-11.458,4.257-15.485,0.413c10.512,14.326,33.363,8.473,36.769-5.325c2.552,0.022,4.051-0.884,4.981-1.882
				C69.529,48.704,67.399,48.445,66.27,47.976z"/>
			</svg></a>

			<a href="http://www.instagram.com/transferMKE" target="_blank">
			
			<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
			<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
			<svg version="1.1" class="social-icons" id="Icons" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 width="28px" height="28px" viewBox="29 29 42 42" enable-background="new 29 29 42 42" xml:space="preserve">
			<path class="social-fill" fill="#FFFFFF" d="M62.877,29.008H37.116c-4.475,0-8.116,3.64-8.116,8.115v8.572v17.191C29,67.36,32.641,71,37.116,71h25.762
				c4.475,0,8.114-3.64,8.114-8.114V45.694v-8.572C70.991,32.647,67.352,29.008,62.877,29.008z M65.204,33.847l0.929-0.003v0.924v6.194
				l-7.094,0.023l-0.024-7.117L65.204,33.847z M44.002,45.694c1.346-1.861,3.527-3.081,5.994-3.081s4.648,1.22,5.992,3.081
				c0.875,1.214,1.399,2.7,1.399,4.31c0,4.076-3.318,7.389-7.393,7.389c-4.075,0-7.391-3.313-7.391-7.389
				C42.605,48.394,43.128,46.908,44.002,45.694z M66.9,62.884c0,2.22-1.805,4.023-4.023,4.023H37.116c-2.22,0-4.024-1.804-4.024-4.023
				v-17.19h6.268c-0.542,1.332-0.845,2.786-0.845,4.31c0,6.33,5.15,11.482,11.482,11.482s11.482-5.152,11.482-11.482
				c0-1.523-0.307-2.978-0.848-4.31h6.27V62.884z"/>
			</svg></a>
			
			<a href="http://www.pinterest.com/transferMKE" target="_blank">
			
			<!-- Generator: Adobe Illustrator 16.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0)  -->
			<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
			<svg version="1.1" class="social-icons" id="Icons" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
				 width="28px" height="28px" viewBox="29 29 42 42" enable-background="new 29 29 42 42" xml:space="preserve">
			<path class="social-fill" fill="#FFFFFF" d="M51.258,29C39.785,29,34,37.225,34,44.085c0,4.153,1.572,7.848,4.944,9.223
				c0.553,0.229,1.049,0.009,1.209-0.604c0.111-0.422,0.375-1.492,0.493-1.938c0.161-0.605,0.098-0.817-0.348-1.346
				c-0.972-1.146-1.595-2.63-1.595-4.735c0-6.102,4.566-11.565,11.888-11.565c6.486,0,10.049,3.962,10.049,9.252
				c0,6.963-3.082,12.84-7.656,12.84c-2.526,0-4.416-2.088-3.811-4.651c0.726-3.059,2.131-6.359,2.131-8.569
				c0-1.976-1.062-3.625-3.256-3.625c-2.582,0-4.657,2.672-4.657,6.25c0,2.279,0.771,3.821,0.771,3.821s-2.643,11.197-3.106,13.158
				c-0.922,3.905-0.139,8.692-0.072,9.174c0.039,0.288,0.407,0.357,0.575,0.141c0.237-0.311,3.314-4.107,4.358-7.902
				c0.297-1.074,1.699-6.637,1.699-6.637c0.839,1.602,3.291,3.008,5.898,3.008c7.762,0,13.029-7.075,13.029-16.547
				C66.543,35.67,60.477,29,51.258,29z"/>
			</svg></a>
		</div> <!-- End of Social -->

    <section id="home">
      <div class="slide" id="slidemain">
			<div id="gallery" class="cycle-slideshow" 
			    data-cycle-slides="div" data-cycle-speed="1100" data-cycle-timeout="4400" >
			    <style type="text/css">
				    #first_slide {
	  					background-image: url('<?php the_field('slider_1_image_large'); ?>');
	  				}

	  				#second_slide {
	  					background-image: url('<?php the_field('slider_2_image_large'); ?>');
	  				}

	  				#third_slide {
	  					background-image: url('<?php the_field('slider_3_image_large'); ?>');
	  				}

					@media screen and (max-width: 868px) {
						#first_slide {
	 						background-image: url('<?php the_field('slider_1_image_medium'); ?>');
						}

						#second_slide {
	 						background-image: url('<?php the_field('slider_2_image_medium'); ?>');
						}

						#third_slide {
	 						background-image: url('<?php the_field('slider_3_image_medium'); ?>');
						}
					}

					@media screen and (max-width: 420px) {
						#gallery div { 
    						height: 420px; 
 						}

						#first_slide {
	 						background-image: url('<?php the_field('slider_1_image_small'); ?>');
						}

						#second_slide {
	 						background-image: url('<?php the_field('slider_2_image_small'); ?>');
						}

						#third_slide {
	 						background-image: url('<?php the_field('slider_3_image_small'); ?>');
						}		
					}
				</style>
			    <div id="first_slide"><p class="slider-progress"></p></div>
			    <div id="second_slide"><p class="slider-progress-2"></div>
			    <div id="third_slide"><p class="slider-progress-3"></div>
			</div>
		</div><!-- end of 'slide' -->
    </section>

 <section id="specials">
    	<div class="section-container">
    		<img class="specials-banner" src="<?php bloginfo( 'template_url' ); ?>/images/specials-banner-3.png">
			<div id="horizontalTab">
            	<ul class="resp-tabs-list">
	                <li>Mon</li>
	                <li>Tue</li>
	                <li>Wed</li>
	                <li>Thu</li>
	                <li>Sat</li>
	                <li>Sun</li>
	                <li>Happy Hour</li>
            	</ul>

            	<div class="resp-tabs-container">
	                <div class="animated fadeIn">
	                   <?php while ( have_posts() ) : the_post(); ?><p>
	                    <?php the_field('monday_special'); ?>
	                    </p><?php endwhile; // end of the loop. ?>
	                </div>

	                <div class="animated fadeIn">
	                    <p>
	                    <?php the_field('tuesday_special'); ?>
	                    </p>
	                </div>

	                <div class="animated fadeIn">
	                    <p>
	                    <?php the_field('wednesday_special'); ?>
	                    </p>
	                </div>

	                <div class="animated fadeIn">
	                    <p>
	                    <?php the_field('thursday_special'); ?>
	                    </p>
	                </div>

	                <div class="animated fadeIn">
	                   <p>
	                    <?php the_field('saturday_special'); ?>
	                    </p>
	                </div>

	                <div class="animated fadeIn">
	                   <p>
	                    <?php the_field('sunday_special'); ?>
	                    </p>
	                </div>

	                <div class="animated fadeIn">
	                   <p>
	                    <?php the_field('happy_hour_special'); ?>
	                    </p>
	                </div>
				</div> <!-- End of resp-tabs-container -->
			</div> <!-- End of horizontalTab div -->
		</div> <!-- End of section-container -->
    </section> <!-- End of Specials section -->

 <section id="food">
       <div class="section-container">
       		<h3 class="food-title-mobile">FOOD MENU</h3>
       	      <div id="verticalTab">
            <ul class="resp-tabs-list">
                <li>Antipasti</li>
                <li>Salads</li>
                <li>Pizzas</li>
                <li>Pastas</li>
                <li>Panini</li>
                <li>Gluten Free</li>
            </ul>
            <div class="resp-tabs-container vert-class">
                <div class="animated fadeIn food-style">
                    <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_field('antipasti_items'); ?>
					<?php endwhile; // end of the loop. ?>
                    
					<h5><span class="gluten" aria-hidden="true" data-icon="&#xe600;" class="down-arrow"></span> = Available GLUTEN FREE! $2 extra</h5>

					
                </div>
                <div class="animated fadeIn food-style">
                    <?php while ( have_posts() ) : the_post(); ?>
                    <?php the_field('salad_items'); ?>
					<?php endwhile; // end of the loop. ?>

					<h5><span class="gluten" aria-hidden="true" data-icon="&#xe600;" class="down-arrow"></span> = Available GLUTEN FREE! $2 extra</h5></p>
                </div>
                <div class="animated fadeIn food-style">
                    <p>
                    	<ul class="tabs">
						    <li><a href="#view1">Garlic</a></li>
						    <li><a href="#view2">Traditional</a></li>
						    <li><a href="#view3">Veggie</a></li>
						    <li><a href="#view4">Seafood</a></li>
						    <li><a href="#view5">Special</a></li>
						</ul>
						<div class="tabcontents">
						    <div id="view1" class="animated fadeIn">
						        <?php while ( have_posts() ) : the_post(); ?>
			                    <?php the_field('garlic_pizza_items'); ?>
								<?php endwhile; // end of the loop. ?>
						    </div>
						    <div id="view2" class="animated fadeIn">
						        <?php while ( have_posts() ) : the_post(); ?>
			                    <?php the_field('traditional_pizza_items'); ?>
								<?php endwhile; // end of the loop. ?>
						    </div>
						    <div id="view3" class="animated fadeIn">
						    	<?php while ( have_posts() ) : the_post(); ?>
			                    <?php the_field('veggie_pizza_items'); ?>
								<?php endwhile; // end of the loop. ?>
						      
						    </div>
						    <div id="view4" class="animated fadeIn">
						        <?php while ( have_posts() ) : the_post(); ?>
			                    <?php the_field('seafood_pizza_items'); ?>
								<?php endwhile; // end of the loop. ?>
						    </div>
						    <div id="view5" class="animated fadeIn">
						        <?php while ( have_posts() ) : the_post(); ?>
			                    <?php the_field('special_pizza_items'); ?>
								<?php endwhile; // end of the loop. ?>
						    </div>
						</div>
                    </p>
                </div>
                <div class="food-style animated fadeIn">
                    <?php while ( have_posts() ) : the_post(); ?>
			        <?php the_field('pasta_items'); ?>
					<?php endwhile; // end of the loop. ?>
						
					
                </div>
                <div class="food-style animated fadeIn">
                    <?php while ( have_posts() ) : the_post(); ?>
			        <?php the_field('panini_items'); ?>
					<?php endwhile; // end of the loop. ?>
					
					
                </div>
                <div class="food-style animated fadeIn">
               		<?php while ( have_posts() ) : the_post(); ?>
			        <?php the_field('gluten-text'); ?>
					<?php endwhile; // end of the loop. ?>
                </div>
            </div>
        </div>
		</div> <!-- End of tabs-container -->
    </section>

<section id="drinks">
		<div class="section-container">
		    <h3 class="food-title-mobile">DRINKS MENU</h3>
		       	<div id="verticalTab-2">
		            <ul class="resp-tabs-list">
		                <li>Wine</li>
		                <li>Birra</li>
		                <li>Cocktails</li>
		                <li>Martinis</li>
		                <li>Spirits</li>
		                <li>Digestivi</li>
		            </ul>
		            <div class="resp-tabs-container vert-class drinks-class">
		                <div class="animated fadeIn drinks-style">
							<?php while ( have_posts() ) : the_post(); ?>
			        		<?php the_field('wine_glass_items'); ?>
							<?php endwhile; // end of the loop. ?>
							
							

		        		</div> <!-- End of Wine -->

		        		<div class="animated fadeIn drinks-style">
							<?php while ( have_posts() ) : the_post(); ?>
			        		<?php the_field('birra_items'); ?>
							<?php endwhile; // end of the loop. ?>
						
						
		        		</div> <!-- End of Birra -->

						<div class="animated fadeIn drinks-style">
							<?php while ( have_posts() ) : the_post(); ?>
			        		<?php the_field('cocktail_items'); ?>
							<?php endwhile; // end of the loop. ?>


		        		</div> <!-- End of Seasonal Drinks -->

		        		<div class="animated fadeIn drinks-style">
							<?php while ( have_posts() ) : the_post(); ?>
			        		<?php the_field('martini_items'); ?>
							<?php endwhile; // end of the loop. ?>

		        		</div> <!-- End of Martinis -->

		        		<div class="animated fadeIn drinks-style columner">
		        			<?php while ( have_posts() ) : the_post(); ?>
			        		<?php the_field('spirits_items'); ?>
							<?php endwhile; // end of the loop. ?>

						

							
						
							
		        		</div> <!-- End of Spirits -->

		        		<div class="animated fadeIn drinks-style digestivi">
							<?php while ( have_posts() ) : the_post(); ?>
			        		<?php the_field('digestivi_items_1'); ?>
							<?php endwhile; // end of the loop. ?>

						</div>





		        	</div> <!-- End of resp-tabs-container -->
		        </div> <!-- End of verticalTab-2 -->
		</div> <!-- End of section-container -->
    </section>

    <section id="contact">
   	 		<div id="map_canvas"></div>

			<div id="contact-info-container">
				<div class="contact-info join">
					<strong><p>Join us!</p>
					<span>Join our email list</span></br>
					<span>Join our Birthday Club</span></strong></br></br>
				</div>

				<div class="contact-info comments">
					<strong>Comments, suggestions, inquiries: <span><a href="mailto:shout@transfermke.com" target="_blank">shout@transfermke.com</a></span></strong></br></br>
				</div>

				<div class="contact-info staff">
					<strong>General Manager:  
					<span><a href="mailto:maggie@transfermke.com" target="_blank">Maggie McCanna</a></span></strong></br></br>
				</div>

				<div class="contact-info staff">
					<strong>Lead Pizzaiolo:  
					<span><a href="mailto:danny@transfermke.com" target="_blank">Danny Goodale</a></span></strong></br></br>
				</div>

				<div class="contact-info staff">
					<strong>Co-Owner:  
					<span> <a href="mailto:jro@transfermke.com" target="_blank">John Rossetto</a></span></strong></br></br>
				</div>

				<div class="contact-info staff">
					<strong>Co-Owner: 
					<span> <a href="mailto:russelletto@transfermke.com" target="_blank">Russell Rosetto</a></span></strong></br></br>
				</div>
			</div>
					
    </section>
<div class="bottom-logo">
		<img class="logo-img" src="<?php bloginfo( 'template_url' ); ?>/images/LautobusTransfer.png">
	</div>
	</div><!-- #primary -->







<?php get_footer(); ?>
